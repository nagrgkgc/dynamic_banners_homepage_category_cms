<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Kharvi\Dbanner\Ui\Component\Listing\Column\Bannertype;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Options
 */
class Yesno implements OptionSourceInterface
{
    /**
     * @var array
     */
    protected $options;

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return[
            [
                'value' => 1,
                'label' => __('Enabled'),
            ],
            [
                'value' => 0,
                'label' => __('Disabled'),
            ]
        ];
    }
}
