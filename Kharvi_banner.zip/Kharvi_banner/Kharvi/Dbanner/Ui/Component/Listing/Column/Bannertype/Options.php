<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Kharvi\Dbanner\Ui\Component\Listing\Column\Bannertype;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Options
 */
class Options implements OptionSourceInterface
{
    /**
     * @var array
     */
    protected $options;

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return[
            [
                'value' => 'home',
                'label' => __('Homepage'),
            ],
            [
                'value' => 'category_top',
                'label' => __('Category Top'),
            ],
            [
                'value' => 'category_footer',
                'label' => __('Category Footer'),
            ],
            [
                'value' => 'cms',
                'label' => __('CMS Header'),
            ]
        ];
    }
}
