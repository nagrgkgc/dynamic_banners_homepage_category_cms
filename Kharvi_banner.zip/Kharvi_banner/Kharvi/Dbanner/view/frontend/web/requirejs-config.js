var config = {
    map: {
        '*': {
            kharvidbanner_addtocart: 'Kharvi_Dbanner/js/dbanner'
        }
    }
};