require(["jquery", "mage/url", "mage/calendar"], function($, url){
    $(document).ready(function() {
        url.setBaseUrl(BASE_URL);
        var ajaxUrl = url.build('dbanner/index/index');
        var ajaxPushUrl = url.build('dbanner/index/push');
        //write your code here
        $('body').on('click', '.d_lk', function(){
            if($(this).attr('rel') == 'd_p_b'){
                $('.d_p_w').show();
            }
            
            return false;
        })
        
        $('body').on('click', '.d_btn', function(){
            if($(this).hasClass('d_c')){
                $('.d_p_w').hide();
            }
        })
        
        $('#dfrom').datepicker({
           prevText: '&#x3c;zurück', prevStatus: '',
            prevJumpText: '&#x3c;&#x3c;', prevJumpStatus: '',
            nextText: 'Vor&#x3e;', nextStatus: '',
            nextJumpText: '&#x3e;&#x3e;', nextJumpStatus: '',
            monthNames: ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'],
            monthNamesShort: ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'],
            dayNames: ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'],
            dayNamesShort: ['So','Mo','Di','Mi','Do','Fr','Sa'],
            dayNamesMin: ['So','Mo','Di','Mi','Do','Fr','Sa'],
            showMonthAfterYear: false,
            dateFormat:'d.m.yy'
        });
        
        $('#dto').datepicker({
           prevText: '&#x3c;zurück', prevStatus: '',
            prevJumpText: '&#x3c;&#x3c;', prevJumpStatus: '',
            nextText: 'Vor&#x3e;', nextStatus: '',
            nextJumpText: '&#x3e;&#x3e;', nextJumpStatus: '',
            monthNames: ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'],
            monthNamesShort: ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'],
            dayNames: ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'],
            dayNamesShort: ['So','Mo','Di','Mi','Do','Fr','Sa'],
            dayNamesMin: ['So','Mo','Di','Mi','Do','Fr','Sa'],
            showMonthAfterYear: false,
            dateFormat:'d.m.yy'
        });
        
        $('body').on('click', '.close_popup, .close_form',function(){
            $('.d_pop').hide();
            $(".d_pop_in").html('');
            return false;
        });
        
        $('body').on('click', '.delete_banner',function(){
            if(confirm('Are you sure want to delete?')){
                var id = '';
                if($(this).hasClass('banner_action')){
                    id=$(this).attr('rel');
                }
                
                $.ajax({
                    url: ajaxUrl,
                    type: 'GET',
                    data: {bid : id, action: 'delete'},
                    success: function (response) {
                        //var returnedData = JSON.parse(response);
                        alert("banner has been deleted");
                        window.location.href = window.location.search;
                    },
                    error: function (response) {
                        alert('error! please try again.');
                    }
                });
            }
            return false;
        });
        
        $('body').on("click", ".d_c_b, .edit_banner", function () {
            $('.d_pop').show().children('.d_pop_in').html('Loading ...');
            
            var id = '';
            if($(this).hasClass('banner_action')){
                id=$(this).attr('rel');
            }
            
            $.ajax({
                url: ajaxUrl,
                type: 'GET',
                data: {bid : id},
                success: function (response) {
                    //var returnedData = JSON.parse(response);
                    $(".d_pop_in").html(response);
                    
                    $('#from_date').datepicker({
                       prevText: '&#x3c;zurück', prevStatus: '',
                        prevJumpText: '&#x3c;&#x3c;', prevJumpStatus: '',
                        nextText: 'Vor&#x3e;', nextStatus: '',
                        nextJumpText: '&#x3e;&#x3e;', nextJumpStatus: '',
                        monthNames: ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'],
                        monthNamesShort: ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'],
                        dayNames: ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'],
                        dayNamesShort: ['So','Mo','Di','Mi','Do','Fr','Sa'],
                        dayNamesMin: ['So','Mo','Di','Mi','Do','Fr','Sa'],
                        showMonthAfterYear: false,
                        dateFormat:'d.m.yy'
                    });
                    
                    $('#to_date').datepicker({
                       prevText: '&#x3c;zurück', prevStatus: '',
                        prevJumpText: '&#x3c;&#x3c;', prevJumpStatus: '',
                        nextText: 'Vor&#x3e;', nextStatus: '',
                        nextJumpText: '&#x3e;&#x3e;', nextJumpStatus: '',
                        monthNames: ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'],
                        monthNamesShort: ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'],
                        dayNames: ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'],
                        dayNamesShort: ['So','Mo','Di','Mi','Do','Fr','Sa'],
                        dayNamesMin: ['So','Mo','Di','Mi','Do','Fr','Sa'],
                        showMonthAfterYear: false,
                        dateFormat:'d.m.yy'
                    });
                },
                error: function (response) {
                    alert('error! please try again.');
                    $('.d_pop').hide();
                }
            });
            return false;
        });
        
        $('body').on("click", ".submit_popup", function () {
            $('.submit_popup > span').html('Processing..');
            var data = $('#dbanner-form').serialize();
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: data,
                success: function (response) {
                    //var returnedData = JSON.parse(response);
                    $(".d_status").show().html(response);
                    $('.submit_popup > span').html('Submit');
                },
                error: function (response) {
                    alert('error! please try again.');
                    $('.submit_popup > span').html('Submit');
                }
            });
            return false;
        });
        
        $.fn.insertParam = function(_url_params, key, value)
        {
            key = encodeURI(key); value = encodeURI(value);
            
            if(_url_params !== undefined && _url_params!=''){
                var kvp = _url_params.split('&');
            
                var i=kvp.length; var x; while(i--) 
                {
                    x = kvp[i].split('=');
            
                    if (x[0]==key)
                    {
                        x[1] = value;
                        kvp[i] = x.join('=');
                        break;
                    }
                }
            
                if(i<0) {kvp[kvp.length] = [key,value].join('=');}
            
                //this will reload the page, it's likely better to store this until finished
                return kvp.join('&'); 
            }else{
                return key+"="+value;
            }
        }
        
        $('body').on("click", "#preview", function () {
            var from_date = $('#dfrom').val();
            var to_date = $('#dto').val();
            var stage = 0;
            if ($('#show_stage').is(":checked"))
            {
                stage = 1;
            }
            var current_url = $('#current_url').val();
            
            var urls = current_url.split('?'); 
            var base_url = urls[0];
            var _url_params = urls[1];
            
            _url_params = $.fn.insertParam(_url_params, 'from_date', from_date);
            _url_params = $.fn.insertParam(_url_params, 'to_date', to_date);
            _url_params = $.fn.insertParam(_url_params, 'stage', stage);
            
            window.location.href = base_url + '?' + _url_params;
        });
        
        $('body').on('click', '.d_t_p a', function(){
            $.ajax({
                url: ajaxPushUrl,
                type: 'GET',
                data: {},
                success: function (response) {
                    alert(response);
                },
                error: function (response) {
                    alert('error! please try again.');
                }
            });
            return false;
        })
    });
});