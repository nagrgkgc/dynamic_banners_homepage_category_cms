<?php
namespace Kharvi\Dbanner\Controller\Index;
use Magento\Framework\App\RequestInterface;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_resultPageFactory;
	protected $_resultJsonFactory;
	
	/**
     * Request instance
     *
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $request;
    protected $dbannerFactory;
    protected $_coreRegistry;
    protected $_helper;
    protected $_connection;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		RequestInterface $request,
		\Kharvi\Dbanner\Model\DbannerFactory $dbannerFactory,
		\Magento\Framework\Registry $coreRegistry,
		\Kharvi\Dbanner\Helper\Data $helper,
		\Magento\Framework\App\ResourceConnection $resource
	)
	{
		$this->_resultPageFactory = $resultPageFactory;
		$this->_resultJsonFactory = $resultJsonFactory;
		$this->request = $request;
		$this->dbannerFactory = $dbannerFactory;
		$this->_coreRegistry = $coreRegistry;
		$this->_helper = $helper;
		$this->_connection = $resource->getConnection();
		return parent::__construct($context);
	}

	public function execute()
	{
		$postData = $this->request->getPost('page_identifier');
		$result = $this->_resultJsonFactory->create();
	    
	    $id = $this->getRequest()->getParam('bid');
    	if(!empty($id) && $id!=''){
    		$action = $this->getRequest()->getParam('action');
    		if(!empty($action) && $action == 'delete'){
    			$this->_helper->deleteBanner($id);
    			
    			$result->setData(['success'=> 1]);
    			return $result;
    		}
		}
	    
	    try {
			if($postData && $postData!=''){
				$data = $this->getRequest()->getPostValue();
				$id = $this->getRequest()->getParam('bid');
				
				if($id && $id!=''){
					$dbanner = $this->dbannerFactory->create()->load($id);
					
					//move gps
					$previousPos = $dbanner->getBannerGp();
					$newPos = $data['banner_gp'];
					
					if ($previousPos != $newPos) {
						$this->_helper->moveAllRecordsByOne($data['banner_gp']);
					}
					
					unset($data['page_type']);
					unset($data['page_identifier']);
					unset($data['bid']);
					
					$where = ['id = ?' => (int)$id];
					$tableName = $this->_connection->getTableName("kharvi_dbanner");
    				$this->_connection->update($tableName, $data, $where);
				}else{
					$dbanner = $this->dbannerFactory->create();
					
					$dbanner->setData($data);
					$dbanner->save();
				}
				
				$block = "Successfully added/updated.";
			}else{
				$resultPage = $this->_resultPageFactory->create();
				$data = array();
				
	        	$block = $resultPage->getLayout()
	                ->createBlock('Kharvi\Dbanner\Block\Index')
	                ->setTemplate('Kharvi_Dbanner::index.phtml')
	                ->setData('data',$data)
	                ->toHtml();
			}
	    } catch (\Exception $e) {
	        $block = $e->getMessage();
	    }
	    
		$result->setData($block);
        return $result;
	}
}