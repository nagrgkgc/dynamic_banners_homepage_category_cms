<?php
namespace Kharvi\Dbanner\Controller\Index;
use Magento\Framework\App\RequestInterface;

class Push extends \Magento\Framework\App\Action\Action
{
	protected $_resultPageFactory;
	protected $_resultJsonFactory;
	
	/**
     * Request instance
     *
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $request;
    protected $dbannerFactory;
    protected $_coreRegistry;
    protected $_helper;
    protected $_connection;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		RequestInterface $request,
		\Kharvi\Dbanner\Model\DbannerFactory $dbannerFactory,
		\Magento\Framework\Registry $coreRegistry,
		\Kharvi\Dbanner\Helper\Data $helper,
		\Magento\Framework\App\ResourceConnection $resource
	)
	{
		$this->_resultPageFactory = $resultPageFactory;
		$this->_resultJsonFactory = $resultJsonFactory;
		$this->request = $request;
		$this->dbannerFactory = $dbannerFactory;
		$this->_coreRegistry = $coreRegistry;
		$this->_helper = $helper;
		$this->_connection = $resource->getConnection();
		return parent::__construct($context);
	}

	public function execute()
	{
		$result = $this->_resultJsonFactory->create();
		
	    try {
	    	//take backup file 
	    	$backup = $this->_helper->takeBackups();
	    	
	    	if(isset($backup['status']) && $backup['status']){
				$message = "success! pushed successfully.";
	    	}else{
	    		$message = "error! please see error logs.";
	    	}
	    } catch (\Exception $e) {
	        $message = $e->getMessage();
	    }
	    
		$result->setData($message);
        return $result;
	}
}