<?php
namespace Kharvi\Dbanner\Controller\Adminhtml\Dbanner;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Pull extends \Magento\Backend\App\Action
{

    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'Kharvi_Dbanner::dbanner';

    /**
     * @var PageFactory 
     */
    protected $resultPageFactory;

    protected $_dir;
    protected $_deploymentConfig;
    protected $_logger;
    protected $_connection;
    protected $helper;
    protected $_timezone;
    
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context, 
        PageFactory $resultPageFactory,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Framework\Filesystem\DirectoryList $dir,
        \Magento\Framework\App\DeploymentConfig $deploymentConfig,
        \Kharvi\Dbanner\Logger\Logger $logger,
        \Kharvi\Dbanner\Helper\Data $helper,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->_dir = $dir;
        $this->_deploymentConfig = $deploymentConfig;
        $this->_logger = $logger;
        $this->_connection = $resource->getConnection();
        $this->helper = $helper;
        $this->_timezone = $timezone;
        
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultRedirectFactory->create();
              
        try{  
            $importFlag = 0;
            $baseDir = $this->_dir->getPath('var');
    	    $dropPath = $baseDir . '/dbanner/';
    	    $currentDate = $this->_timezone->date()->format('Y-m-d');
    	    
    	    // S3 details
    		//$s3 = $this->helper->getS3();
    		
    		$host = $this->_deploymentConfig->get('db/connection/default/host');
            $user = $this->_deploymentConfig->get('db/connection/default/username');
            $pass = $this->_deploymentConfig->get('db/connection/default/password');
            $dbname = $this->_deploymentConfig->get('db/connection/default/dbname');
            $remotePath = $this->helper->getStoreConfigValue('kharvi_dbanner/general/aws_path');
            $bucket= $this->helper->getStoreConfigValue('kharvi_dbanner/general/s3_bucket');
            
            // Clone existing tables
    		$createQuery = "CREATE TABLE IF NOT EXISTS kharvi_dbanner_clone LIKE kharvi_dbanner;";
    		$this->_connection->query($createQuery);
    		$trQuery = "TRUNCATE TABLE kharvi_dbanner_clone;";
    		$this->_connection->query($trQuery);
    		$cloneQuery = "INSERT kharvi_dbanner_clone SELECT * FROM kharvi_dbanner;";
    		$this->_connection->query($cloneQuery);
    		
    		// Check no of rows in clone table must be qual to no of rows in original table, then only start import_request_variables
    		$countQueryCl ='SELECT COUNT(*) as count FROM kharvi_dbanner_clone';
    		$resultCl = $this->_connection->fetchAll($countQueryCl);
    		
    		$countQueryOrigi ='SELECT COUNT(*) as count FROM kharvi_dbanner ';
    		$resultOrigi = $this->_connection->fetchAll($countQueryOrigi);
    		if(count($resultCl) == 1 && count($resultOrigi) == 1){
    			if($resultCl[0]['count'] == $resultOrigi[0]['count']){
    				$importFlag = 1;
    			}
    		}
    			
    		// Take backup of current tables
    		$dbBkFileName = 'production_dbanners-'.$currentDate.'.sql'; // Current db backup file name
    		$dbBkDropPath = $baseDir . '/dbanner/';
    		if(!is_dir($dbBkDropPath)) {
    			mkdir($dbBkDropPath , 0777);
    		}
    		
    		$dbBkDropPath = $dbBkDropPath.$dbBkFileName;
    		if(file_exists($dbBkDropPath)){
    			unlink($dbBkDropPath);
    		}
    		
    		$sql = "mysqldump -h '". $host ."' -u '". $user ."' -p'".$pass."' '".$dbname."' kharvi_dbanner > '". $dbBkDropPath . "'";
            shell_exec($sql);
            
    		// move current backup file to s3
    		/*$putDbBk = $s3->putObject(array(
    		    'Bucket'       => $bucket,
    		    'Key'          => $remotePath . $dbBkFileName,
    		    'SourceFile'   => $dbBkDropPath,
    		)); */
    		
    		// backup file moved successfully on s3 then get production backup file from s3 and import into current db
    		//if(isset($putDbBk) && $importFlag && $putDbBk['@metadata']['statusCode'] == 200){ 
    			// Move Production Homepage backup file from s3 to current server at $dropPath
    			$dropPath = $baseDir . '/dbanners/';
    			
    			if(!is_dir($dropPath)) {
    				mkdir($dropPath , 0777);
    			}
    			$fileName = 'staging_dbanners-'.$currentDate.'.sql';  
    			$dropPath = $dropPath.$fileName;
    			
    			if(file_exists($dropPath)){
    				unlink($dropPath);
    			}
    			
    			/*$get = $s3->getObject(array(
    			    'Bucket'       => $bucket,
    			    'Key'          => $remotePath . $fileName,
    			    'SaveAs'   => $dropPath,
    			));
    			
    			if(isset($get) && $get['@metadata']['statusCode'] == 200){*/
    				try{
    					$sql = "mysql -h '". $host ."' -u '". $user ."' -p'".$pass."' '".$dbname."' < '". $dropPath . "'";
    					shell_exec($sql);
    					$successMsg = 'Banner has been Updated successfully.';
    					$this->_logger->info($successMsg);
    					$this->helper->notifyMail($successMsg);
    					$this->messageManager->addSuccess(__($successMsg));
    				}catch(\Exception $e){
    					$trQuery = "TRUNCATE TABLE kharvi_dbanner;";
    					$cloneOriginl = "INSERT kharvi_dbanner SELECT * FROM kharvi_dbanner_clone;";
    					$this->_connection->query($trQuery.$cloneOriginl);
    					$_exceptionMsg = $e->getMessage();
    					$this->_logger->error($_exceptionMsg);
    					$this->messageManager->addError($_exceptionMsg);
    					$this->helper->notifyMail($e->getMessage());
    				}
    			/*}else{
    				$errorMsg = $this->__('while fetching staging file from S3, response status code is not 200...');
    				$this->_logger->error($errorMsg);
    				$this->messageManager->addError($errorMsg);
    				$this->_helper->notifyMail($errorMsg);
    			}*/
    		/*}else{
    			$errorMsg = 'Either home page backup file not moved to s3 or cloning of original table has some issue...';
    			$this->_logger->error($errorMsg);
    			$this->_helper->notifyMail($errorMsg);
    			$this->messageManager->addError($errorMsg);
    			$this->messageManager->addSuccess(__('Successfully saved the item.'));
    		}*/
        }catch(\Exception $e){
			$this->_logger->error($e->getMessage());
			$this->helper->notifyMail($e->getMessage());
			$this->messageManager->addError($e->getMessage());
		}
    	    
        return $resultPage->setPath('*/*/index');
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Kharvi_Dbanner::dbanners');
    }
}