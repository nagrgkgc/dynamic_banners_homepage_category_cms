<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */

namespace Kharvi\Dbanner\Model\Config\Source;

class GetEnvMode implements \Magento\Framework\Option\ArrayInterface
{   
    public function toOptionArray()
    {
        return [
            ['value' => 'dev', 'label' => __('DEV')],
            ['value' => 'uat', 'label' => __('UAT')],
            ['value' => 'stage', 'label' => __('Stage')],
            ['value' => 'prod', 'label' => __('Prod')]
        ];
    }
}