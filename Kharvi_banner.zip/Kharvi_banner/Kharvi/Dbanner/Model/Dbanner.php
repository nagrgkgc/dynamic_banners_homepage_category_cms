<?php

namespace Kharvi\Dbanner\Model;

use Magento\Framework\Model\AbstractModel;
use Magento\Framework\DataObject\IdentityInterface;
use Kharvi\Dbanner\Api\Data\DbannerInterface;

class Dbanner extends AbstractModel implements DbannerInterface, IdentityInterface
{

    const CACHE_TAG = 'kharvi_dbanner';
    
    protected $_cacheTag = self::CACHE_TAG;

    protected $_eventPrefix = self::CACHE_TAG;


    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Kharvi\Dbanner\Model\ResourceModel\Dbanner::class);
    }

    /**
     * Return unique ID(s)
     *
     * @return string[]
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get id
     *
     * @return int|null
     */
    public function getId()
    {
        return $this->getData(self::ID);
    }

    /**
     * Set id
     *
     * @param int $id
     * @return $this
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * Get title
     *
     * @return string|null
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * Set title
     *
     * @param string $title
     * @return $this
     */
    public function setName($title)
    {
        return $this->setData(self::NAME, $title);
    }

    /**
     * Get content
     *
     * @return string|null
     */
    public function getImageUrl()
    {
        return $this->getData(self::URL_KEY);
    }

    /**
     * Set content
     *
     * @param string $content
     * @return $this
     */
    public function setImageUrl($content)
    {
        return $this->setData(self::URL_KEY, $content);
    }

    /**
     * Get created date
     *
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * Set created date
     *
     * @param string $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated date
     *
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

    /**
     * Set updated date
     *
     * @param string $updatedAt
     * @return $this
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * status
     *
     * @return bool|null
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * Set status
     *
     * @param int|bool $status
     * @return $this
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

}