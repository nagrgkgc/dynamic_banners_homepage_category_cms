<?php
namespace Kharvi\Dbanner\Block;
use Magento\Framework\Registry;

class Dbanner extends \Magento\Framework\View\Element\Template {
    protected $_storeManager; 
    protected $_scopeConfig;
    private $_registry;
    protected $_page;
    protected $_helper;
    
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Cms\Model\Page $page,
        Registry $registry,
        \Kharvi\Dbanner\Helper\Data $helper
    )
    {
        $this->_storeManager = $storeManager;
        $this->_scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_page = $page;
        $this->_helper = $helper;
        parent::__construct($context);
    }
    
    public function isDisplayEditor(){
        return $this->_helper->getStoreConfigValue('kharvi_dbanner/general/env_mode');
    }
    
    public function isModuleElabled(){
        return $this->_helper->getStoreConfigValue('kharvi_dbanner/general/is_active');
    }
    
    public function getCategoryId(){
        $category = $this->_registry->registry('current_category');
        
        if($category){
            return $category->getId();
        }
        
        return '';
    }
    
    public function getPageId(){
        $pageId='0';
        if ($this->_page->getId()) {
            $pageId = $this->_page->getId();
        }
        
        return $pageId;
    }
    
    public function getCurrentPageUrl(){
        return $this->_helper->getCurrentUrl();
    }
    
    public function getBannerEditablePerm(){
	    return $this->_helper->isCustomerAuthorized();
	}
	
	public function getFromDate(){
	    return $this->_request->getParam('from_date');
	}
	
	public function getToDate(){
	    return $this->_request->getParam('to_date');
	}
	
	public function getStage(){
	    return $this->_request->getParam('stage');
	}
    
    /**
     * Get store identifier
     *
     * @return  int
     */
    public function getStoreId()
    {
        return $this->_storeManager->getStore()->getId();
    }

    /**
     * Get website identifier
     *
     * @return string|int|null
     */
    public function getWebsiteId()
    {
        return $this->_storeManager->getStore()->getWebsiteId();
    }

    /**
     * Get Store code
     *
     * @return string
     */
    public function getStoreCode()
    {
        return $this->_storeManager->getStore()->getCode();
    }

    /**
     * Get Store name
     *
     * @return string
     */
    public function getStoreName()
    {
        return $this->_storeManager->getStore()->getName();
    }

    /**
     * Get current url for store
     *
     * @param bool|string $fromStore Include/Exclude from_store parameter from URL
     * @return string     
     */
    public function getStoreUrl($fromStore = true)
    {
        return $this->_storeManager->getStore()->getCurrentUrl($fromStore);
    }

    /**
     * Check if store is active
     *
     * @return boolean
     */
    public function isStoreActive()
    {
        return $this->_storeManager->getStore()->isActive();
    }
}