<?php
namespace Kharvi\Dbanner\Block;
use Magento\Framework\Registry;

class Category extends \Magento\Framework\View\Element\Template {
    protected $_storeManager; 
    protected $_scopeConfig;
    private $_registry;
    protected $_page;
    protected $_helper;
    
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Cms\Model\Page $page,
        Registry $registry,
        \Kharvi\Dbanner\Helper\Data $helper
    )
    {
        $this->_storeManager = $storeManager;
        $this->_scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_page = $page;
        $this->_helper = $helper;
        parent::__construct($context);
    }
    
    public function getBannerBlocks($bannerType){
        $category = $this->_registry->registry('current_category');
        $identifier = $category->getId();
        
		$result = $this->_helper->getBannerBlocks($bannerType, $identifier);

        if (!$result) {
            return array();
        }

        return $result;
	}
	
	public function getBannerBaseUrl(){
	    return $this->_helper->getStoreConfigValue('kharvi_dbanner/general/base_url');
	}
	
	public function getMediaBaseUrl(){
	    return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
	}
	
	public function getBannerEditablePerm(){
	    return $this->_helper->isCustomerAuthorized();
	}
}