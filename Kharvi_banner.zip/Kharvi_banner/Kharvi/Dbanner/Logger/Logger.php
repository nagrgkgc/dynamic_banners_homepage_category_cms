<?php
namespace Kharvi\Dbanner\Logger;

class Logger extends \Monolog\Logger
{
}