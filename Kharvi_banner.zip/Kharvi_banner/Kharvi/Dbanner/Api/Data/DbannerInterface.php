<?php

namespace Kharvi\Dbanner\Api\Data;

interface DbannerInterface {
    
    /**
     * Constants for keys of data array.
     */
    const ID = 'id';
    const NAME = 'name';
    const IMAGE_URL = 'image_url';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const STATUS = 'status';

    /**
     * Get id
     *
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     *
     * @param int $id
     * @return $this
     */
    public function setId($id);

    /**
     * Get title
     *
     * @return string|null
     */
    public function getName();

    /**
     * Set title
     *
     * @param string $title
     * @return $this
     */
    public function setName($title);

    /**
     * Get content
     *
     * @return string|null
     */
    public function getImageUrl();

    /**
     * Set content
     *
     * @param string $content
     * @return $this
     */
    public function setImageUrl($image_url);

    /**
     * Get created date
     *
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created date
     *
     * @param string $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated date
     *
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated date
     *
     * @param string $updatedAt
     * @return $this
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Is status
     *
     * @return bool|null
     */
    public function getStatus();

    /**
     * Set is status
     *
     * @param int|bool $status
     * @return $this
     */
    public function setStatus($isActive);
}
