<?php

namespace Kharvi\Dbanner\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface DbannerRepositoryInterface
{

    /**
     * Save banner
     *
     * @param \Kharvi\Dbanner\Api\Data\DbannerInterface $dbanner
     * @return \Kharvi\Dbanner\Api\Data\DbannerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(Data\DbannerInterface $dbanner);

    /**
     * Retrieve dbanner
     *
     * @param int $dbannerId
     * @return \Kharvi\Dbanner\Api\Data\DbannerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($dbannerId);


    /**
     * Retrieve dbanners matching the specified criteria
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Kharvi\Dbanner\Api\Data\DbannerSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
    
    /**
     * Delete banner
     *
     * @param \Kharvi\Dbanner\Api\Data\DbannerInterface $dbanner
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(Data\DbannerInterface $dbanner);

    /**
     * Delete banner by ID
     *
     * @param int $dbannerId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($id);
}
