<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */

namespace Kharvi\Dbanner\Helper;

use Magento\Framework\UrlInterface;
use Magento\Customer\Model\Session as CustomerSession;

use Aws\S3\S3Client;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $_catalogHelper;
    protected $_storeManager;
    protected $_registry;
    protected $_catalogSearchData;
    protected $_categoryRepository;
    protected $_escaper;
    protected $_urlBuilder;
    protected $_request;
    protected $_scopeConfig;
    protected $_currency;
    protected $_timezone;
    protected $_connection;
    protected $_urlInterface;
    protected $_customerSession;
    protected $_dir;
    protected $_deploymentConfig;
    public $_s3;
    protected $_logger;
    
    public $final_url_data = array();
    public $_filtersList = array();
    
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Helper\Data $catalogHelper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\CatalogSearch\Helper\Data $catalogSearchData,
        \Magento\Catalog\Model\CategoryRepository $categoryRepository,
        \Magento\Framework\Escaper $_escaper,
        UrlInterface $urlBuilder,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory $productAttributeCollectionFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Directory\Model\Currency $currency,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Framework\UrlInterface $urlInterface,
        CustomerSession $customerSession,
        \Magento\Framework\Filesystem\DirectoryList $dir,
        \Magento\Framework\App\DeploymentConfig $deploymentConfig,
        \Kharvi\Dbanner\Logger\Logger $logger
    ){
        $this->_registry = $registry;
        $this->_catalogHelper = $catalogHelper;
        $this->_storeManager = $storeManager;
        $this->_catalogSearchData = $catalogSearchData;
        $this->_categoryRepository = $categoryRepository;
        $this->_escaper=$_escaper;
        $this->_urlBuilder = $urlBuilder;
        $this->_request = $request;
        $this->productAttributeCollectionFactory = $productAttributeCollectionFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->_currency = $currency; 
        $this->_timezone = $timezone;
        $this->_connection = $resource->getConnection();
        $this->_urlInterface = $urlInterface;
        $this->_customerSession = $customerSession;
        $this->_dir = $dir;
        $this->_deploymentConfig = $deploymentConfig;
        $this->_logger = $logger;
         
        parent::__construct($context);
    }
    
    public function getStoreConfigValue($key){
        return $this->_scopeConfig->getValue($key, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    
    public function getBannerBlocks($bannerType, $identifier){
		$todayDate = $this->_timezone->date()->format('Y-m-d H:i:s');
		
		$fromDate = $this->_request->getParam('from_date');
		$toDate = $this->_request->getParam('to_date');
		$stage = $this->_request->getParam('stage');
		
		$select = "select * from kharvi_dbanner where ((DATE_FORMAT('$todayDate', '%Y-%m-%d %H:%i:%s') between DATE_FORMAT(from_date,'%Y-%m-%d %H:%i:%s') and DATE_FORMAT(to_date,'%Y-%m-%d %H:%i:%s') ";
        
        if($fromDate!=''){ $select .= " AND from_date >= DATE_FORMAT('$fromDate', '%Y-%m-%d %H:%i:%s')";}
        if($toDate!=''){ $select .= " AND to_date <= DATE_FORMAT('$toDate', '%Y-%m-%d %H:%i:%s')";}
        
        $select .= ")";
        
        $env_mode = $this->getStoreConfigValue('kharvi_dbanner/general/env_mode');
        if(!in_array($env_mode, array('prod')) && !empty($stage) && $stage==1){
            $select .= " or (is_stage = 1)";
        }
        
        $select .= ")";
        
        $select .= " AND banner_type='$bannerType'";
        $select .= " AND page_identifier='$identifier'";
        //$select .= " AND status='$identifier'";
        
		$select .= " order by banner_gp ASC, banner_sorting ASC";
        $result = $this->_connection->fetchAll($select);

        if (!$result) {
            return array();
        }

        return $result;
	}
	
	public function getCurrentUrl(){
	    return $this->_urlInterface->getCurrentUrl();
	}
	
	public function isCustomerAuthorized() {
	    $customer = false;
	    if($this->_customerSession->isLoggedIn()) {
	        $email = $this->_customerSession->getCustomer()->getEmail();
            $emails = explode(',', $this->getStoreConfigValue('kharvi_dbanner/general/users'));
            if (isset($email) && in_array($email, $emails)) {
                $customer = true;
            }
        }
        
        $env_mode = false;
        $env = $this->getStoreConfigValue('kharvi_dbanner/general/env_mode');
        if(!in_array($env, array('prod'))){
            $env_mode = true;
        }
        
        if($customer && $env_mode){
            return true;
        }
        
        return false;
    }
    
    public function deleteBanner($id){
        $select = "delete from kharvi_dbanner where id='$id'";
        $result = $this->_connection->query($select);
        
        return true;
    }
    
    public function moveAllRecordsByOne($new_pos){
		$pos = $new_pos - 1;
		$select = "update kharvi_dbanner set banner_gp = banner_gp+1 where banner_gp > $pos";

        $result = $this->_connection->query($select);

        if (!$result) {
            return array();
        }

        return $result;
	}
	
	public function takeBackups(){
	    try{
    	    $var = $this->_dir->getPath('var');
    	    $dropPath = $var . '/dbanner/';
    	    
    	    $currentDate = $this->_timezone->date()->format('Y-m-d');
            if(!is_dir($dropPath)) {
                mkdir($dropPath , 0777);
            }
            
            $fileName = 'staging_dbanners-'.$currentDate.'.sql';
            $filePath = $dropPath .$fileName ;
            
            $host = $this->_deploymentConfig->get('db/connection/default/host');
            $user = $this->_deploymentConfig->get('db/connection/default/username');
            $pass = $this->_deploymentConfig->get('db/connection/default/password');
            $dbname = $this->_deploymentConfig->get('db/connection/default/dbname');
            $remotePath = $this->getStoreConfigValue('kharvi_dbanner/general/aws_path');
            $bucket= $this->getStoreConfigValue('kharvi_dbanner/general/s3_bucket');
            
            $sql = "mysqldump -h '". $host ."' -u '". $user ."' -p'".$pass."' '".$dbname."' kharvi_dbanner > '". $filePath . "'";
            shell_exec($sql);
            
            //push to s3
            //$s3 = $this->getS3();
            
            /*
    		$put = $s3->putObject(array(
    		    'Bucket'       => $bucket,
    		    'Key'          => $remotePath . $fileName,
    		    'SourceFile'   => $filePath,
    		)); 
    		
            if(isset($put) && $put['@metadata']['statusCode'] == 200){
    			$subject = 'Back up file has been moved to s3 successfully.';
    			$this->_logger->info($subject);
    			$response['status'] = 1;
    			$this->notifyMail($subject);
    			//Mage::getModel('spvarnish/homepage_api')->callPushApi();
            }else{
    			$error = 'while moving staging file to S3, response status code is not 200...';
    			$this->_logger->error($error);
    			$response['status'] = 0;
    			$this->notifyMail($error);
    		}*/
    		$response['status'] = 1;
	    }catch(\Exception $e){
			$error = 'An error occurred while moving the file. Please review the log and try again.' . $e->getMessage();
			$this->_logger->error($error);
			$response['status'] = 0;
			$this->notifyMail($error);
        }
        
        return $response;
	}
	
	public function getS3(){
	    $key = $this->getStoreConfigValue('kharvi_dbanner/general/s3_key');
	    $secret = $this->getStoreConfigValue('kharvi_dbanner/general/s3_secret');
	    $region = $this->getStoreConfigValue('kharvi_dbanner/general/s3_region');
	    
	    if (!$this->_s3) {
			$credentials = array('key' => $key, 'secret' => $secret);
			$options = array(
				'region'            => $region,
				'version'           => 'latest',
				'signature_version' => 'v4',
				'credentials' => $credentials
			);
			$this->_s3 = new S3Client($options);
        }
        return $this->_s3;
	}
	
	public function notifyMail($subject){
		try{
			$noReply = $this->getStoreConfigValue('trans_email/ident_general/email');
			$emailRecipient = $this->getStoreConfigValue('kharvi_dbanner/general/email_recipient');
			$emailIds = explode(',', $emailRecipient);
			if (isset($emailIds) && count($emailIds) > 0) {
				$baseDir = $this->_dir->getPath('var');
				$mailTxtFile = $baseDir . '/dbanner/mailmessage.txt';
				$message = $subject;
				foreach ($emailIds as $id) {
					if (file_exists($mailTxtFile))
					shell_exec("rm ".$mailTxtFile);
					
					shell_exec("touch ".$mailTxtFile);
					shell_exec("echo 'From: ". $noReply ."' >> ".$mailTxtFile);
					shell_exec("echo 'To: ". $id ."' >> ". $mailTxtFile);
					shell_exec("echo 'Subject:" . $subject . "' >> " .$mailTxtFile);
					shell_exec("echo '" . $message . "' >> " . $mailTxtFile);
					shell_exec("/usr/sbin/sendmail -f ".$noReply ." -t < ".$mailTxtFile);
					$this->_logger->info("Notify Mail has been sent to ".$id);
				}
			}
		}catch(\Exception $e){
			$_exceptionMsg = $e->getMessage();
			$this->_logger->error($_exceptionMsg);
		}
	}
}